import { tabRead, tabAppend, rowsToObjects, logEvent, hookToken, trialCap, bizAgeDays } from "./_engine.js";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "POST only" });
  const bizId = ((req.query.b || "") + "").slice(0, 60);
  const key = (req.query.k || "") + "";
  if (!bizId || key !== hookToken(bizId)) return res.status(401).json({ ok: false, error: "bad credentials" });
  const businesses = rowsToObjects(await tabRead("businesses"));
  const biz = businesses.find((x) => x.id === bizId && x.status === "active");
  if (!biz) return res.status(404).json({ ok: false, error: "unknown business" });
  const b = req.body || {};
  // flexible field mapping for Zapier/CRM/POS payloads
  const pick = (...keys) => { for (const k of keys) { if (b[k]) return String(b[k]).slice(0, 120).trim(); } return ""; };
  let first = pick("first", "first_name", "firstname", "given_name");
  if (!first) { const full = pick("name", "full_name", "customer_name", "customer"); first = full.split(" ")[0] || ""; }
  const cell = pick("cell", "phone", "mobile", "phone_number", "customer_phone").replace(/[^0-9+]/g, "");
  const email = pick("email", "customer_email", "email_address");
  const job = pick("job", "service", "job_type", "description", "line_item").slice(0, 80);
  if (!first || (!cell && !email)) return res.status(400).json({ ok: false, error: "need first name plus phone or email" });
  // dedupe: same phone or email already enrolled for this business
  const contacts = rowsToObjects(await tabRead("contacts")).filter((c) => c.biz_id === bizId);
  const norm = (s) => (s || "").replace(/[^0-9]/g, "").slice(-10);
  const dup = contacts.some((c) => (email && c.email && c.email.toLowerCase() === email.toLowerCase()) || (cell && c.cell && norm(c.cell) === norm(cell)));
  if (dup) return res.status(200).json({ ok: true, queued: 0, note: "already enrolled" });
  const inTrial = bizAgeDays(biz) < 30;
  const status = inTrial && contacts.length >= trialCap() ? "waitlist" : "queued";
  await tabAppend("contacts", [[bizId, first, cell, email, job, new Date().toISOString(), "0", status, "", "", ""]]);
  await logEvent("hook_contact", bizId, email || cell, "via webhook " + status);
  return res.status(200).json({ ok: true, queued: status === "queued" ? 1 : 0, waitlisted: status === "waitlist" ? 1 : 0 });
}
