import { tabRead, rowsToObjects, scoreToken } from "./_engine.js";

export default async function handler(req, res) {
  const bizId = ((req.query.b || "") + "").slice(0, 50);
  const t = (req.query.t || "") + "";
  if (!bizId || t !== scoreToken(bizId)) return res.status(403).send("Invalid link.");
  const businesses = rowsToObjects(await tabRead("businesses"));
  const biz = businesses.find((x) => x.id === bizId);
  if (!biz) return res.status(404).send("Not found.");
  const contacts = rowsToObjects(await tabRead("contacts")).filter((c) => c.biz_id === bizId);
  const snaps = rowsToObjects(await tabRead("snapshots")).filter((s) => s.biz_id === bizId);
  const latest = snaps[snaps.length - 1] || {};
  const first = snaps[0] || {};
  const mo = Date.now() - 30 * 86400000;
  const sent = contacts.filter((c) => parseInt(c.seq_stage || 0) > 0 && Date.parse(c.last_send || 0) > mo).length;
  const clicked = contacts.filter((c) => c.clicked_at && Date.parse(c.clicked_at) > mo).length;
  const esc = (s) => String(s).replace(/[<>&]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" }[c]));
  const tile = (k, v, d) => `<div style="background:#fff;border:1px solid #d7e4dc;border-radius:6px;padding:20px"><p style="font-size:.8rem;text-transform:uppercase;letter-spacing:.1em;color:#6e8279;font-weight:700;margin:0">${k}</p><p style="font-size:2.1rem;font-weight:700;font-family:monospace;margin:6px 0 2px">${v}</p><p style="font-size:.85rem;color:#00714b;margin:0">${d}</p></div>`;
  res.setHeader("Content-Type", "text/html");
  return res.status(200).send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>${esc(biz.name)}: Scoreboard</title></head>
<body style="font-family:-apple-system,sans-serif;background:#f6faf7;color:#182620;margin:0;padding:22px">
<div style="max-width:760px;margin:0 auto">
<p style="font-size:.82rem;text-transform:uppercase;letter-spacing:.14em;color:#00714b;font-weight:700">WellEarnedReviews</p>
<h1 style="font-size:1.7rem;margin:4px 0 18px">${esc(biz.name)}</h1>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px">
${tile("Google rating", latest.rating || "&mdash;", first.rating ? "was " + first.rating : "tracking daily")}
${tile("Total reviews", latest.review_count || "&mdash;", first.review_count ? "+" + (parseInt(latest.review_count || 0) - parseInt(first.review_count || 0)) + " since we started" : "tracking daily")}
${tile("Requests sent", String(sent), "last 30 days")}
${tile("Link clicks", String(clicked), "last 30 days")}
</div>
<p style="margin-top:26px;font-size:.94rem;color:#4a4335">This page updates automatically. Questions? Reply to any of our emails.</p>
</div></body></html>`);
}
