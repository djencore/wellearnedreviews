import { sheetReadAll, sheetUpdateCells, resendSend } from "./_util.js";

// Authenticity: instead of raw-body HMAC (fragile behind body parsing), we take
// the event id from the payload and re-fetch the event from Stripe with our
// secret key. A forged id either 404s or returns a different event type.
async function stripeGet(path) {
  const r = await fetch("https://api.stripe.com/v1" + path, {
    headers: { Authorization: "Basic " + Buffer.from(process.env.STRIPE_SECRET_KEY + ":").toString("base64") },
  });
  if (!r.ok) return null;
  return r.json();
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false });
  const id = (req.body || {}).id || "";
  if (!/^evt_[A-Za-z0-9]+$/.test(id)) return res.status(400).json({ ok: false });
  const event = await stripeGet("/events/" + id);
  if (!event) return res.status(400).json({ ok: false });

  if (event.type === "checkout.session.completed") {
    const s = event.data.object;
    const email = ((s.customer_details && s.customer_details.email) || s.customer_email || "").toLowerCase();
    const amount = ((s.amount_total || 0) / 100).toFixed(2);
    // flip every lead row for this email to converted
    let flipped = 0;
    try {
      const rows = await sheetReadAll();
      for (let i = 1; i < rows.length; i++) {
        if ((rows[i][1] || "").toLowerCase() === email && (rows[i][10] || "") !== "converted") {
          await sheetUpdateCells(i + 1, { K: "converted", L: new Date().toISOString() });
          flipped++;
        }
      }
    } catch (e) {}
    await resendSend({
      from: process.env.FROM_ADDR,
      to: [process.env.TO_ADDR],
      subject: "WER payment: " + email + " ($" + amount + ")",
      text: `Stripe checkout completed.\n\nCustomer: ${email}\nAmount: $${amount}\nCustomer id: ${s.customer || "?"}\nSubscription: ${s.subscription || "?"}\nLead rows marked converted: ${flipped}\n\nNext: onboard them at https://wellearnedreviews.com/admin`,
    });
  }

  if (event.type === "customer.subscription.deleted") {
    const sub = event.data.object;
    await resendSend({
      from: process.env.FROM_ADDR,
      to: [process.env.TO_ADDR],
      subject: "WER cancellation: subscription " + sub.id,
      text: `A subscription was canceled.\n\nSubscription: ${sub.id}\nCustomer: ${sub.customer}\nCheck the dashboard for the annual re-rate policy if this was an annual plan canceled early.`,
    });
  }

  return res.status(200).json({ ok: true });
}
