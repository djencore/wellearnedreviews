import crypto from "crypto";
import { saToken, resendSend } from "./_util.js";

const SHEET = () => process.env.SHEET_ID;

export async function tabRead(tab) {
  const tok = await saToken();
  const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SHEET()}/values/${tab}!A:Z`, { headers: { Authorization: "Bearer " + tok } });
  const d = await r.json();
  return d.values || [];
}
export async function tabAppend(tab, rows) {
  const tok = await saToken();
  const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SHEET()}/values/${tab}!A1:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`, {
    method: "POST", headers: { Authorization: "Bearer " + tok, "Content-Type": "application/json" },
    body: JSON.stringify({ values: rows }),
  });
  return r.ok;
}
export async function tabUpdate(tab, rowIndex1, updates) {
  const tok = await saToken();
  const data = Object.entries(updates).map(([col, val]) => ({ range: `${tab}!${col}${rowIndex1}`, values: [[val]] }));
  const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SHEET()}/values:batchUpdate`, {
    method: "POST", headers: { Authorization: "Bearer " + tok, "Content-Type": "application/json" },
    body: JSON.stringify({ valueInputOption: "RAW", data }),
  });
  return r.ok;
}
export async function logEvent(type, bizId, who, detail) {
  try { await tabAppend("events", [[new Date().toISOString(), type, bizId, who, (detail || "").toString().slice(0, 300)]]); } catch (e) {}
}

// ---- Twilio ----
export async function smsSend(to, body) {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const auth = Buffer.from(process.env.TWILIO_API_KEY_SID + ":" + process.env.TWILIO_API_KEY_SECRET).toString("base64");
  const form = new URLSearchParams({ To: to, From: process.env.TWILIO_FROM, Body: body });
  const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
    method: "POST", headers: { Authorization: "Basic " + auth, "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
  });
  return r.ok;
}

// ---- message templates ----
const JOBS = { general: "the work", contractor: "the job", dental: "your visit", salon: "your appointment", auto: "the repair", events: "your event" };
export function renderMsg(stage, biz, contact, clickUrl) {
  const job = contact.job || JOBS[biz.industry] || "the work";
  const f = contact.first;
  if (stage === 0) return `Hey ${f}, it's ${biz.owner_first} from ${biz.name}. Just wanted to make sure everything looks good after ${job}. Anything need a second look?`;
  if (stage === 1) return `Hey ${f}, ${biz.owner_first} from ${biz.name} again. If you've got 30 seconds, a Google review helps us more than you'd think: ${clickUrl} Thanks again!`;
  return `Hey ${f}, ${biz.owner_first} here one last time. No pressure at all, but if you meant to leave that review, here's the link again: ${clickUrl} Either way, thank you!`;
}
export function renderEmail(stage, biz, contact, clickUrl) {
  const f = contact.first;
  if (stage === 0) return { subject: "Everything look good?", text: `Hi ${f},\n\nThis is ${biz.owner_first} from ${biz.name}. Just checking that everything looks good after the job. If anything needs a second look, reply here and I'll take care of it.\n\n${biz.owner_first}` };
  if (stage === 1) return { subject: "Quick favor?", text: `Hi ${f},\n\nThanks again for your business. If you were happy with how everything turned out, would you take 30 seconds to share it in a Google review? It's the single biggest way people find us.\n\n${clickUrl}\n\nAnd if anything wasn't right, just reply and I'll fix it personally.\n\n${biz.owner_first}\n${biz.name}` };
  return { subject: "One last nudge", text: `Hi ${f},\n\n${biz.owner_first} here one last time. If you meant to leave that review and life got busy, here's the link again:\n\n${clickUrl}\n\nEither way, thank you for the business.\n\n${biz.owner_first}\n${biz.name}` };
}

export function clickToken() { return crypto.randomBytes(6).toString("hex"); }
export function hookToken(bizId) {
  return crypto.createHmac("sha256", process.env.CRON_SECRET).update("hook:" + bizId).digest("hex").slice(0, 20);
}
export function scoreToken(bizId) {
  return crypto.createHmac("sha256", process.env.CRON_SECRET).update("score:" + bizId).digest("hex").slice(0, 20);
}
export function trialCap() { return parseInt(process.env.TRIAL_CAP || "50"); }
export function bizAgeDays(biz) {
  const t = Date.parse(biz.created || "");
  return isNaN(t) ? 999 : (Date.now() - t) / 86400000;
}
export function inSendWindow() {
  const h = parseInt(new Intl.DateTimeFormat("en-US", { hour: "numeric", hour12: false, timeZone: "America/Los_Angeles" }).format(new Date()));
  return h >= 9 && h < 18;
}
export function rowsToObjects(rows) {
  if (!rows || rows.length < 2) return [];
  const head = rows[0];
  return rows.slice(1).map((r, i) => {
    const o = { _row: i + 2 };
    head.forEach((h, j) => (o[h] = r[j] || ""));
    return o;
  });
}
export async function placeDetails(placeId) {
  const r = await fetch(`https://places.googleapis.com/v1/places/${placeId}?fields=rating,userRatingCount`, {
    headers: { "X-Goog-Api-Key": process.env.GOOGLE_PLACES_KEY, "Referer": "https://wellearnedreviews.com/" },
  });
  if (!r.ok) return null;
  return r.json();
}
