import { tabRead, tabAppend, rowsToObjects, logEvent, scoreToken, hookToken, trialCap, bizAgeDays } from "./_engine.js";

export default async function handler(req, res) {
  if ((req.headers.authorization || "") !== "Bearer " + process.env.ADMIN_SECRET) return res.status(401).json({ ok: false });
  const b = req.body || {};
  if (req.method === "GET" || b.action === "list") {
    const businesses = rowsToObjects(await tabRead("businesses"));
    const contacts = rowsToObjects(await tabRead("contacts"));
    return res.status(200).json({ ok: true, businesses: businesses.map(x => ({...x, scoreboard: `https://wellearnedreviews.com/api/scoreboard?b=${x.id}&t=${scoreToken(x.id)}`, webhook: `https://wellearnedreviews.com/api/hook?b=${x.id}&k=${hookToken(x.id)}`})), contactCounts: contacts.reduce((m, c) => ((m[c.biz_id] = (m[c.biz_id] || 0) + 1), m), {}) });
  }
  if (b.action === "add_business") {
    const id = (b.name || "biz").toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 30) + "-" + Math.floor(Date.now() / 1000).toString(36);
    await tabAppend("businesses", [[id, b.name, b.owner_first, b.owner_cell || "", b.owner_email || "", b.review_link || "", b.place_id || "", b.sms_ok ? "yes" : "no", b.industry || "general", "active", new Date().toISOString()]]);
    await logEvent("business_added", id, b.owner_email || "", b.name);
    return res.status(200).json({ ok: true, id, scoreboard: `https://wellearnedreviews.com/api/scoreboard?b=${id}&t=${scoreToken(id)}`, webhook: `https://wellearnedreviews.com/api/hook?b=${id}&k=${hookToken(id)}` });
  }
  if (b.action === "add_contacts") {
    const businesses = rowsToObjects(await tabRead("businesses"));
    const biz = businesses.find((x) => x.id === b.biz_id);
    if (!biz) return res.status(404).json({ ok: false, error: "unknown business" });
    const existing = rowsToObjects(await tabRead("contacts")).filter((c) => c.biz_id === b.biz_id).length;
    const inTrial = bizAgeDays(biz) < 30;
    const cap = trialCap();
    let queued = 0, waitlisted = 0;
    const rows = (b.contacts || []).slice(0, 500).map((c) => {
      const status = inTrial && existing + queued >= cap ? "waitlist" : "queued";
      if (status === "queued") queued++; else waitlisted++;
      return [b.biz_id, c.first || "", c.cell || "", c.email || "", c.job || "", new Date().toISOString(), "0", status, "", "", ""];
    });
    if (!rows.length) return res.status(400).json({ ok: false });
    await tabAppend("contacts", rows);
    await logEvent("contacts_added", b.biz_id, "", `${queued} queued, ${waitlisted} waitlisted`);
    return res.status(200).json({ ok: true, added: rows.length, queued, waitlisted });
  }
  return res.status(400).json({ ok: false, error: "unknown action" });
}
